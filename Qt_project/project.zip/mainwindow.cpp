#include "mainwindow.h"

#include <QInputDialog>
#include <qlabel.h>
#include <QVBoxLayout>
#include <qgridlayout.h>

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);
}

MainWindow::~MainWindow()
{
	delete ui;
}

void MainWindow::saveInfo(int idx)
{
	cnt = 0;
	std::locale::global(std::locale("kor")); // encoding

	QString str = ui->lineEdit->text(); // text â ���
	wstring tag = str.toStdWString();

	html.tag = tag;
	// �˻� ��� ������ �Ľ�
	html.htmlGet("result.html", L"https://search.daum.net/", SEARCH);

	HtmlParser htmlparser; // 
	cnt = htmlparser.resultParsing();

	if (idx >= 0)
	{
		ExtractArticleText article(htmlparser);

		article.loadHtmlFile(idx);
		article.titleText();
		article.mainText();
		article.loadImage();

		mainTxt[idx] = QString::fromStdWString(article.main_txt);
		mainTxt[idx].replace("&middot;", ",");
		mainTxt[idx].replace("&quot;", "\"");
		mainTxt[idx].replace("&nbsp;", " ");
		mainTxt[idx].replace("&lt;", "<");
		mainTxt[idx].replace("&gt;", ">");


		title[idx] = QString::fromStdWString(article.title);
		title[idx].replace("&middot;", ",");
		title[idx].replace("&quot;", "\"");
		title[idx].replace("&nbsp;", " ");
		title[idx].replace("&lt;", "<");
		title[idx].replace("&gt;", ">");

		img[idx] = article.img;
	}
}

void MainWindow::showInfo(int idx)
{
	//QString filename = "image.jpg"; //  �̹��� ���� �̸� �ҷ�����
	//QImage image(filename);
	//QPixmap buf = QPixmap::fromImage(image);

	QWidget *window = new QWidget; // ���ο� ���� ����
	QGridLayout *gridLayout;
	QScrollArea *scrollArea;
	QWidget *scrollAreadWidget;
	QGridLayout *gridLayout_2;
	QImage *img = new QImage();
	QPixmap *buf = new QPixmap();


	QLabel *titleLabel ;
	QLabel *mainLabel;
	QLabel *imageLabel ;
	
	QFont titleFont;
	QFont mainFont;

	titleFont.setFamily(QString::fromUtf8("\353\247\221\354\235\200 \352\263\240\353\224\225"));
	mainFont.setFamily(QString::fromUtf8("\353\247\221\354\235\200 \352\263\240\353\224\225"));

	window->resize(800, 600);

	gridLayout = new QGridLayout(window);
	gridLayout->setSpacing(6);
	gridLayout->setContentsMargins(11, 11, 11, 11);
	gridLayout->setObjectName(QStringLiteral("gridLayout"));

	scrollArea = new QScrollArea(window);
	scrollArea->setObjectName(QStringLiteral("scrollArea"));
	scrollArea->setWidgetResizable(true);

	scrollAreadWidget = new QWidget();
	scrollAreadWidget->setObjectName(QStringLiteral("scrollAreadWidget"));
	scrollAreadWidget->setGeometry(QRect(0, 0, 535, 555));

	gridLayout_2 = new QGridLayout(scrollAreadWidget);
	gridLayout_2->setSpacing(6);
	gridLayout_2->setContentsMargins(11, 11, 11, 11);
	gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
	
	titleLabel = new QLabel(scrollAreadWidget);
	titleFont.setBold(true);
	titleFont.setPointSize(16);
	titleLabel->setFont(titleFont);
	titleLabel->setAlignment(Qt::AlignCenter);
	titleLabel->setText(title[idx]);
	
	
	imageLabel = new QLabel(scrollAreadWidget);
	imageLabel->setAlignment(Qt::AlignCenter);

	if (img->load("image.jpg"))
	{
		*buf = QPixmap::fromImage(*img);
		*buf = buf->scaled(img->width(), img->height());
		
		imageLabel->setPixmap(*buf);
		imageLabel->resize(buf->width(), buf->height());
	}
	else
		imageLabel->setText("Image load Error");


	mainLabel = new QLabel(scrollAreadWidget);
	mainFont.setPointSize(11);
	mainLabel->setFont(mainFont);
	mainLabel->setAlignment(Qt::AlignLeft);
	mainLabel->setText(mainTxt[idx]);

	gridLayout_2->addWidget(titleLabel, 0, 0, 1, 1);
	gridLayout_2->addWidget(imageLabel,1, 0, 1, 1);
	gridLayout_2->addWidget(mainLabel, 2, 0, 1, 1);

	scrollArea->setWidget(scrollAreadWidget);
	gridLayout->addWidget(scrollArea, 0, 0, 1, 1);
	
	window->setLayout(gridLayout);
	window->show();
}

/* --- Event �Լ� ----*/
void MainWindow::on_pushButton_clicked()
{
	ui->listWidget->clear();
	title->clear();
	mainTxt->clear();
	img->clear();
	
	std::thread tw = saveInfoThread(-1);
	//saveInfo(-1);
	for (int i = 0; i <cnt; i++)
	{
		tw = saveInfoThread(i);
		ui->listWidget->addItem(QString("%1 " + title[i]).arg(i+1));
	}
	tw.join();
}

void MainWindow::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
	QString idx = item->text().section(" ", 0, 0);
	int index = idx.toInt()-1;
	html.htmlGet("image.jpg", img[index], -1);
	showInfo(index);
}

