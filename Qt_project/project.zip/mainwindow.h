#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <locale>
#include <string>
#include <thread>
#include <iostream>

#include <QtWidgets\qlistwidget.h>
#include "ui_mainwindow.h"
#include "ExtractArticleText.h"
namespace Ui {
	class MainWindow;
}

class MainWindow : public QMainWindow
{
	Q_OBJECT

public:
	explicit MainWindow(QWidget *parent = 0);
	~MainWindow();

	private slots:
	void on_pushButton_clicked();
	void on_listWidget_itemDoubleClicked(QListWidgetItem *item);
	/*void on_commandLinkButton_clicked();
	void on_commandLinkButton_2_clicked();
	void on_commandLinkButton_3_clicked();
	void on_commandLinkButton_4_clicked();
	void on_commandLinkButton_5_clicked();*/


public:
	/* --- my code --- */
	void saveInfo(int idx)
	{
		{
			cnt = 0;
			std::locale::global(std::locale("kor")); // encoding

			QString str = ui->lineEdit->text(); // text â ���
			wstring tag = str.toStdWString();

			html.tag = tag;
			// �˻� ��� ������ �Ľ�
			html.htmlGet("result.html", L"https://search.daum.net/", SEARCH);

			HtmlParser htmlparser; // 
			cnt = htmlparser.resultParsing();

			if (idx >= 0)
			{
				ExtractArticleText article(htmlparser);

				article.loadHtmlFile(idx);
				article.titleText();
				article.mainText();
				article.loadImage();

				mainTxt[idx] = QString::fromStdWString(article.main_txt);
				mainTxt[idx].replace("&middot;", ",");
				mainTxt[idx].replace("&quot;", "\"");
				mainTxt[idx].replace("&nbsp;", " ");
				mainTxt[idx].replace("&lt;", "<");
				mainTxt[idx].replace("&gt;", ">");


				title[idx] = QString::fromStdWString(article.title);
				title[idx].replace("&middot;", ",");
				title[idx].replace("&quot;", "\"");
				title[idx].replace("&nbsp;", " ");
				title[idx].replace("&lt;", "<");
				title[idx].replace("&gt;", ">");

				img[idx] = article.img;
			}
		}
	}
	void showInfo(int idx);

	std::thread saveInfoThread(int idx)
	{
		return std::thread([=] { saveInfo(idx); });
	}

	QString title[20];
	QString mainTxt[20];
	wstring img[20];

	HtmlRequest html;
	int cnt;
	/* end */

private:
	Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H